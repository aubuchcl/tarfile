#!/bin/sh


while [true]
do
  echo "Hello Im a script"
  sleep 10
done
