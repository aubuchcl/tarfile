#!/usr/bin/python3
import time


while True:
  print("Hello from alpine")
  time.sleep(30)
