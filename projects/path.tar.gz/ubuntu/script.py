#!/usr/bin/python3
import time


while True:
  print("Hello from bunt roo")
  time.sleep(30)
